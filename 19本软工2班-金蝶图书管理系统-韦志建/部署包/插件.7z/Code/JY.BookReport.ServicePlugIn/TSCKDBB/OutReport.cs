using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Kingdee.BOS.Contracts;
using Kingdee.BOS.Contracts.Report;
using Kingdee.BOS.Core.Metadata;
using Kingdee.BOS.Core.Report;
using System.ComponentModel;
using Kingdee.BOS;

namespace JY.BookReport.ServicePlugIn.TSCKDBB
{
    [Kingdee.BOS.Util.HotUpdate]
    [Description("图书借书订单")]
    public class OutReport : SysReportBaseService
    {
        public override void Initialize()
        {
            this.ReportProperty.ReportType = ReportType.REPORTTYPE_NORMAL; 
            this.ReportProperty.ReportName = new LocaleValue("图书借书订单执行明细表", base.Context.UserLocale.LCID); 
            this.IsCreateTempTableByPlugin = true; 
            this.ReportProperty.IsUIDesignerColumns = false; 
            this.ReportProperty.IsGroupSummary = true; 
            this.ReportProperty.SimpleAllCols = false; // 单据主键：两行 FID 相同，则为同一单的两条分录，单据编号可以不重复显示 //this.ReportProperty.PrimaryKeyFieldName = "FID";
            this.ReportProperty.IsDefaultOnlyDspSumAndDetailData = true;
            // 报表主键字段名：默认为 FIDENTITYID，可以修改
            this.ReportProperty.IdentityFieldName = "FIDENTITYID"; //替换显示内容
            //this.ReportProperty.DspInsteadColumnsInfo.DefaultDspInsteadColumns.Add("FCustId", "FCustNumber"); 
            //this.ReportProperty.DspInsteadColumnsInfo.DefaultDspInsteadColumns.Add("FMaterialId", "FMaterialNumber");
        }

        /// <summary>
        /// 动态够着列
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>
        public override ReportHeader GetReportHeaders(IRptParams filter)
        {
            ReportHeader header = new ReportHeader(); //构造表头
            var LentID = header.AddChild("FLentID", new LocaleValue("借书订单号"));
            LentID.ColIndex = 0;
            var ISBNid = header.AddChild("FISBN", new LocaleValue("ISBN编码"));
            ISBNid.ColIndex = 1;
            var BookName = header.AddChild("FBookName", new LocaleValue("书籍名称"));
            BookName.ColIndex = 2;
            var CusName = header.AddChild("FCustName", new LocaleValue("借阅者名称"));
            CusName.ColIndex = 3;
            var CusPhone = header.AddChild("FCustPhone", new LocaleValue("借阅者电话"));
            CusPhone.ColIndex = 4;
            var CusAddress = header.AddChild("FCustAddress", new LocaleValue("借阅者地址"));
            CusAddress.ColIndex = 5;
            var LentNum = header.AddChild("FLentNum", new LocaleValue("借出数量"));
            LentNum.ColIndex = 6;
            var Date = header.AddChild("FLentDate", new LocaleValue("借书日期"));
            Date.ColIndex = 7;


            //MaterialName.ColIndex = 7; 
            //var Unit = header.AddChild("FUnit", new LocaleValue("销售单位")); 
            //Unit.ColIndex = 8; 
            //var CurrencyId = header.AddChild("FCurrencyId", new LocaleValue("币别")); 
            //CurrencyId.ColIndex = 9; 
            //var OrderQty = header.AddChild("FOrderQty", new LocaleValue("销售&数量"), SqlStorageType.SqlDecimal); 
            //OrderQty.ColIndex = 10; 
            //var OrderAmount = header.AddChild("FOrderAmount", new LocaleValue("销售&金额"), SqlStorageType.SqlDecimal); 
            //OrderAmount.ColIndex = 11; 
            //var OutStockQty = header.AddChild("FOutStockQty", new LocaleValue("出库&数量"), SqlStorageType.SqlDecimal);
            //OutStockQty.ColIndex = 12; 
            //var OutStockAmount = header.AddChild("FOutStockAmount", new LocaleValue("出库&金额"), SqlStorageType.SqlDecimal); 
            //OutStockAmount.ColIndex = 13; 
            return header;
        }
        /// <summary>
        /// 设置报表头
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>
        public override ReportTitles GetReportTitles(IRptParams filter)
        {
            ReportTitles titles = new ReportTitles();
            Kingdee.BOS.Orm.DataEntity.DynamicObject customFilter = filter.FilterParameter.CustomFilter;
            //获取开始日期
            DateTime filterSoDateFrom = Convert.ToDateTime(customFilter["F_JY_SoFromDate"]);
            //获取结束日期
            DateTime filterSoDateTo = Convert.ToDateTime(customFilter["F_JY_SoToDate"]);
            string strDate = string.Format("{0}~{1}", filterSoDateFrom, filterSoDateTo);
            titles.AddTitle("F_JY_DateScope", strDate);
            return titles;
        }


        /// <summary>
        /// 构造取数Sql，取数据填充到临时表：tableName
        /// </summary>
        /// <param name="filter"></param>
        /// <param name="tableName"></param>
        public override void BuilderReportSqlAndTempTable(IRptParams filter, string tableName)
        {
            //获取自定义过滤对象
            Kingdee.BOS.Orm.DataEntity.DynamicObject customFilter = filter.FilterParameter.CustomFilter;
            //获取开始日期
            DateTime filterSoDateFrom = Convert.ToDateTime(customFilter["F_JY_SoFromDate"]);
            //获取结束日期
            DateTime filterSoDateTo = Convert.ToDateTime(customFilter["F_JY_SoToDate"]);
            //构造过滤条件
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendLine(" ");
            if (filterSoDateFrom > DateTime.MinValue)
            {
                stringBuilder.AppendLine(string.Format(" AND T1.F_JY_FCREATEDATE1>={0} ", "{ts'" + filterSoDateFrom.ToString("yyyy-MM-dd HH:mm:ss")
                + "'}"));
            }
            if (filterSoDateTo < DateTime.MaxValue)
            {
                stringBuilder.AppendLine(string.Format(" AND T1.F_JY_FCREATEDATE1<{0} ", "{ts'" + filterSoDateTo.AddDays(1.0).Date.ToString("yyyy-MM-dd HH:mm:ss") + "'}"));
            }
            string sqlwhere = stringBuilder.ToString();



            string sortStr = filter.FilterParameter.SortString; 
            KSQL_SEQ = string.Format(KSQL_SEQ, string.IsNullOrWhiteSpace(sortStr) ? " T.FLentDate asc" : sortStr);

            //T1 = JY_t_Cust100053 借书单据头
            //T1_E = JY_t_Cust_Entry100033 借书单据体
            //T1_BK = JY_t_BOOK001 图书信息
            //T2 = JY_t_Cust100047 用户单据体
            //T2_L = JY_t_Cust100047_L 用户名称所在的表

            string sql = string.Format(@" select 
            T1.F_JY_FBILLNO as FLentID 
            ,T1_BK.F_JY_BOOKISBN as FISBN 
            ,T1_BK.F_JY_BOOKNAME as FBookName 
            ,T2_L.F_JY_FNAME as FCustName 
            ,T2.F_JY_TEL as FCustPhone 
            ,T2.F_JY_ADDRESS as FCustAddress 
            ,T1_E.F_JY_QTY1 as FLentNum 
            ,T1.F_JY_FCREATEDATE1 as FLentDate
            from JY_t_Cust_Entry100033 T1_E 
            left join JY_t_Cust100053 T1 on T1.F_JY_FBILLNO=T1_E.F_JY_SOURCEBILLNO 
            left join JY_t_BOOK001 T1_BK on T1_BK.FID=T1_E.F_JY_BOOKID 
            left join JY_t_Cust100047 T2 on T1.F_JY_BASE=T2.FMasterId 
            left join JY_t_Cust100047_L T2_L on T2.FMasterId=T2_L.FID 
            where T1_E.F_JY_SOURCEBILLNO != '' {0}", sqlwhere); 
            
            sql = string.Format(@"SELECT T.*,{0} INTO {1} FROM ({2}) T", KSQL_SEQ, tableName, sql); 
            //第三步：执行脚本
            Kingdee.BOS.App.Data.DBUtils.Execute(Context, sql);

        }

        /// <summary>
        /// 设置汇总行，只有显示财务信息时才需要汇总
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>
        public override List<SummaryField> GetSummaryColumnInfo(IRptParams filter)
        {
            List<SummaryField> summaryList = new List<SummaryField>();
            return summaryList;
        }
    }
}
