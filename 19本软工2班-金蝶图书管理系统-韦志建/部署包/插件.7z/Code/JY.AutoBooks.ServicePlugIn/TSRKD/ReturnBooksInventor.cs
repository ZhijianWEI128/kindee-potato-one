﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Kingdee.BOS.Core.DynamicForm.PlugIn;
using Kingdee.BOS.Core.DynamicForm.PlugIn.Args;
using Kingdee.BOS.Orm.DataEntity;
using Kingdee.BOS.Core.Validation;
using System.ComponentModel;


namespace JY.AutoBooks.ServicePlugIn.TSRKD
{
    [Kingdee.BOS.Util.HotUpdate]
    [Description("还书时改变图书数量")]
    public class ReturnBooksInventor : AbstractOperationServicePlugIn
    {
        public override void OnPreparePropertys(PreparePropertysEventArgs e)
        {
            //e.FieldKeys.Add("");将需要应用的字段Key加入
        }

        /// <summary>
        /// 添加校验器
        /// </summary>
        /// <param name="e"></param>
        public override void OnAddValidators(AddValidatorsEventArgs e)
        {
            var operValidator = new OperValidator();
            operValidator.AlwaysValidate = true;
            operValidator.EntityKey = "FBillHead";
            e.Validators.Add(operValidator);
        }

        /// <summary>
        /// 操作开始前功能处理
        /// </summary>
        /// <param name="e"></param>
        public override void BeginOperationTransaction(BeginOperationTransactionArgs e)
        {
            foreach (DynamicObject o in e.DataEntitys)
            {
            }
        }

        /// <summary>
        /// 操作结束后功能处理
        /// </summary>
        /// <param name="e"></param>
        public override void EndOperationTransaction(EndOperationTransactionArgs e)
        {
            //还书操作，已借数量减少，可借数量增加，该插件是用在图书出库单里面

            foreach (DynamicObject o in e.DataEntitys)//每张单的遍历
            {
                DynamicObjectCollection entrydata = o["Entity"] as DynamicObjectCollection;//每一行数据的遍历

                foreach (var item in entrydata)
                {
                    // long bookISBN = Convert.ToInt64(item["F_JY_Base2_Id"]);//获取图书的ISBN
                    DynamicObject objBook = item["F_JY_Base2"] as DynamicObject;
                    long bookISBN = Convert.ToInt64(objBook["JY_BookISBN"]);

                    long borrowBooks = Convert.ToInt64(item["JY_Qty2"]);//获取借出数量的值

                    string borrowedSQL = string.Format("update JY_t_BOOK001 set F_JY_DEBITQTY = F_JY_DEBITQTY - {0} where F_JY_BOOKISBN = {1}", borrowBooks.ToString(), bookISBN.ToString());//改变已借出数量（-）
                    string canBorrowSQL = string.Format("update JY_t_BOOK001 set F_JY_OTHERQTY = F_JY_OTHERQTY + {0} where F_JY_BOOKISBN = {1}", borrowBooks.ToString(), bookISBN.ToString());//改变可借出数量（+）

                    //运行两条SQL语句
                    Kingdee.BOS.Contracts.ServiceFactory.GetDBService(this.Context).Execute(this.Context, borrowedSQL);
                    Kingdee.BOS.Contracts.ServiceFactory.GetDBService(this.Context).Execute(this.Context, canBorrowSQL);
                }
            }
        }


        /// <summary>
        /// 当前操作的校验器
        /// </summary>
        private class OperValidator : AbstractValidator
        {
            public override void Validate(Kingdee.BOS.Core.ExtendedDataEntity[] dataEntities, ValidateContext validateContext, Kingdee.BOS.Context ctx)
            {
                //foreach (var dataEntity in dataEntities)
                //{
                //判断到数据有错误
                //    if()
                //    {
                //        ValidationErrorInfo ValidationErrorInfo = new ValidationErrorInfo(
                //            string.Empty,
                //            dataEntity["Id"].ToString(),
                //            dataEntity.DataEntityIndex,
                //            dataEntity.RowIndex,
                //            dataEntity["Id"].ToString(),
                //            "errMessage",
                //             string.Empty);
                //        validateContext.AddError(null, ValidationErrorInfo);
                //        continue;
                //    }

                //}
            }
        }
    }
}
